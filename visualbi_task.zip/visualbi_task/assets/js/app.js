$(".folders").click(function() {
	$(".folder_preview").fadeIn();	
});

$(".previewclose").click(function(){
	$(".folder_preview").fadeOut();
});